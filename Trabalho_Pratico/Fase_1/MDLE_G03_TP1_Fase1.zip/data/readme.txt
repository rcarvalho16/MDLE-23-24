The submission does not contain data due to the file size.
The data should be extracted from mdle_data.zip in the moodle page, inside this folder

This directory must include:
Weather
INE
_MACOSX
README.md
consumos_horario_codigo_postal.csv